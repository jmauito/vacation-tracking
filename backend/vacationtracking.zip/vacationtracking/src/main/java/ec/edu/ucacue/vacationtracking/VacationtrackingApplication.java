package ec.edu.ucacue.vacationtracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VacationtrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(VacationtrackingApplication.class, args);
	}

}
