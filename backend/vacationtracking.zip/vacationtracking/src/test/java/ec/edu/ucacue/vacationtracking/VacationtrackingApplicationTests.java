package ec.edu.ucacue.vacationtracking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VacationtrackingApplicationTests {

	@Test
	void contextLoads() {
	}

}
